						README

Files contained in this folder:

	1. installation_guide.txt -- Open this file first and follow the instructions to ensure that your computer is ready to play the game.

	2. user_guide.txt -- Open this file next. It will walk you through the few steps needed to open the game and make sure that it runs properly.

	3. design_guide.txt -- Describes the inner workings of the three game modes in this file.

	4. self_evaluation.txt -- A self-evaluation of our group's work over the course of this project.

	5. sc1.png-sc5.png -- A few screenshots demonstrating the game's function. Feel free to blow them up into posters for your wall, photo-shop yourself into them and pretend that you're in Tron, or use them as inspiration for a totally rad series of tattoos.

	6. All other files (.py and .pyc) -- Python scripts necessary for game function.